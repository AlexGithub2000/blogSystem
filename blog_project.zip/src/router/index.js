import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
import SignUp from '../views/SignUp'
import Login from '../views/Login'
import Index from '../views/Index'
import AddArticle from '../views/AddArticle'
import ArticleDetail from '../views/ArticleDetail'
import MyArticle from '../views/MyArticle'
import EditArticle from '../views/EditArticle'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index,
      children:[
        {
          path: '/login',
          name: 'Login',
          component: Login
        },
        {
          path: '/signup',
          name: 'SignUp',
          component: SignUp
        },

      ]
      // redirect:'/login'

    },
    {
      path:'/addarticle',
      name:'AddArticle',
      component:AddArticle
    },
    {
      path:'/article/detail/:id',
      name:'ArticleDetail',
      component:ArticleDetail
    },
    {
      path: '/myarticle',
      name: 'MyArticle',
      component: MyArticle
    },
    {
      path: '/editArticle/:id',
      name: 'EditArticle',
      component: EditArticle
    },
  ]
})
