/**
 * Welcome To Code World !!!
 * Author : Administrator
 * Date   : 2019/1/30 17:02
 * Last Modified : name
 * Good Luck! Happy Codding Young Man !!!
 */
import axios from 'axios'
import qs from 'qs'
import {Message} from 'iview'

axios.defaults.timeout = 5000;
if (process.env.NODE_ENV === 'development') {
  axios.defaults.baseURL = 'http://localhost:3000/blog'
}else {
  axios.defaults.baseURL = '/blog'
}
Window.baseURL = axios.defaults.baseURL
axios.interceptors.request.use(function (config) {
  // 显示loading
  if (config.method === 'post') {
    config.data = qs.stringify(config.data)
  }
  return config
}, function (error) {
  // 请求错误时弹框提示，或做些其他事
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  // 对响应数据做点什么，允许在数据返回客户端前，修改响应的数据
  // 如果只需要返回体中数据，则如下，如果需要全部，则 return response 即可
  return response.data
}, function (error) {
  // 对响应错误做点什么
  return Promise.reject(error)
})

export const request = axios;

export const get = function (url,param) {
  return new Promise((resolve,reject) => {
    axios({
      method:'get',
      url,
      param
    }).then(res=>{
      resolve(res)
    }).catch(err=>{
      Message.error('出错了')
      reject(err)
    })
  })
};

export const post = function (url, data) {
  return new Promise((resolve, reject)=>{
    axios({
      method:'post',
      url,
      data
    }).then(res=>{
      resolve(res)
    }).catch(err=>{
      Message.error('出错了')
      reject(err)
    })
  })
}
