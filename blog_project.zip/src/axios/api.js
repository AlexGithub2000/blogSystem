
import {post,get} from "./axios";

export const api = {
  login(data){
    return post('/login',data)
  },
  signUp(data){
    return post('/signup',data)
  },
  addArticle(data){
    return post('/add/article',data)
  },
  getArticle(data){
    return post('/get/article',data)
  },
  getArticleDetail(data){
    return post('/get/article/detail',data)
  },
  getArticleByUid(data){
    return post('/get/article/mine',data)
  },
  updateArticle(data){
    return post('/update/article',data)
  },
  deleteArticle(data){
    return post('/delete/article',data)
  },
  getMostStar(data){
    return post('/get/star/article',data)
  },
}
