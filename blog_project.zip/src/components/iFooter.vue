<template>
  <Layout>
    <Footer class="blog-footer">Copyright © 2019 斯蒂夫</Footer>
  </Layout>
</template>

<script>
    export default {
        name: "iFooter"
    }
</script>

<style scoped>
  .blog-footer{
    color: #efefef;
    background: #515a6e;
    text-align: center;
  }
</style>
