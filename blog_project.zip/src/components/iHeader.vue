<template>
    <!--<Layout>-->
      <Header class="blog-header">
        <div class="blog-logo">
          原创博客
        </div>
        <div class="blog-nav">
          <ul class="blog-nav-con">
            <router-link class="header-a-tag" to="/"><li>首页</li></router-link>
            <router-link class="header-a-tag" to="/myarticle"><li>我的文章</li></router-link>
            <router-link class="header-a-tag" to="/addarticle"><li>写博客</li></router-link>
            <li>问大家</li>
            <li>时间轴</li>
          </ul>
        </div>
        <div class="blog-btn" v-if="!loginState">
          <router-link to="/signup">
            <Button>注册</Button>
          </router-link>

          <router-link to="/login">
            <Button style="margin-left: 8px;" type="primary">登录</Button>
          </router-link>
        </div>
        <div class="user-center" v-if="loginState">
            <span>你好，</span><span>小明</span>
        </div>
        <!--<div class="blog-search">
          <Input search enter-button @on-search="searchArticle" placeholder="Enter something..." />
        </div>-->
      </Header>
    <!--</Layout>-->
</template>

<script>
    export default {
        name: "iHeader",
      data(){
        return{

        }
      },
      methods:{
        searchArticle(res){
          if (res) {
            console.log(res.trim())

          }
        }
      },
      computed:{
        loginState(){
          return sessionStorage.getItem('userInfo')
        }
      }
    }
</script>

<style scoped>
  .blog-header{
    height: 60px;
    line-height: 60px;
    color: #efefef;
    display: flex;
    /*background: #eee;*/
  }
  .blog-logo{
    padding-left: 20px;
    font-size: 22px;
    float: left;
    flex: 4;
  }
  .blog-nav{
    flex: 18;
    height: 100%;
    margin-left: 50px;
  }
  .blog-nav-con li{
    float: left;
    width: 100px;
    text-align: center;
    display: block;
    font-size: 16px;
    margin-right: 5px;
  }
  .blog-nav-con li:hover{
    background: #3690cf;
    display: block;
    color: #fff;
  }
  .blog-btn{
    flex: 4;
    text-align: center;
  }
  .header-a-tag{
    color: #efefef;
  }
  .router-link-exact-active li{
    background: #3690cf;
    color: #fff;
  }
</style>
