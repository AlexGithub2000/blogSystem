<template>
  <Layout>
    <iHeader></iHeader>
    <Content>
      <Row>
        <Col span="20" offset="2">
          <Card style="margin: 40px 0;">
            <p slot="title" class="article-tittle">{{article.tittle}}
            <Button v-if="isEdit" ghost type="primary" @click="editArticle" style="position: absolute;right: 100px;top: 8px;">编辑</Button>
            <Button v-if="isEdit" ghost type="error" @click="deleteArticle" style="position: absolute;right: 20px;top: 8px;">删除</Button>
            </p>
            <p  v-html="article.content" class="article-content"></p>
          </Card>
        </Col>
      </Row>
    </Content>
    <iFooter></iFooter>
  </Layout>
</template>

<script>
  import iHeader from '../components/iHeader';
  import iFooter from '../components/iFooter';
  import {api} from "../axios/api";

  export default {
      name: "ArticleDetail",
      components:{
        iHeader,
        iFooter
      },
      computed:{
        isEdit(){
          return this.isLogin && this.article.uid == JSON.parse(sessionStorage.getItem('userInfo')).id
        },
        isLogin(){
          return sessionStorage.getItem('userInfo')
        }
      },
      data(){
          return {
            articleId:'',
            content:'',
            article:{
              content:'',
              tittle: ''
            }
          }
      },
      created(){
        this.articleId=this.$route.params.id
        console.log(this.$route.params.id);
        this.getArticleDetail()
      },
      methods:{
        getArticleDetail(){
          try {
            let articleId = this.$route.params.id;
            api.getArticleDetail({articleId}).then(res=>{
              console.log(res);
              if (res.data.state === 200){
                this.article=res.data.article
              }
            }).catch(err=>{
              console.log(err)
            })
          }catch (e) {
            console.log(e)
          }

        },
        editArticle(){
          this.$router.push({path:`/article/detail/${this.articleId}`,name:'EditArticle',params:{id:this.articleId}})
        },
        deleteArticle () {
          this.$Modal.confirm({
            title: '删除',
            content: `<p style="font-size: 14px;">确认删除<span style="font-size: 14px;font-weight: bold;">${this.article.tittle}?</span></p><p style="color: red;">*删除后不能恢复</p>`,
            onOk: () => {
              // this.$Message.info('Clicked ok');
              api.deleteArticle({id:this.articleId}).then(res=>{
                if (res.data.state === 200) {
                  this.$router.go(-1);
                  this.$Message.success('删除成功！')
                }else {
                  this.$Message.error(res.data.msg)
                }
              })
            },
            onCancel: () => {
              // this.$Message.info('Clicked cancel');
            }
          });
        },
      }
    }
</script>

<style scoped>
.article-tittle{
  font-size: 20px;
}
  .article-content{
    font-size: 16px;
  }
  img{
    max-width: 750px;
  }
</style>
