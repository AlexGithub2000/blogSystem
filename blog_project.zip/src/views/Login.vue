<template>
  <!--<div class="from">
    <div class="from-title">
      用户登录
    </div>
    <Form ref="formInline" :model="formInline" :rules="ruleInline" >
      <FormItem prop="userName">
        <Input type="text" v-model="formInline.userName" placeholder="用户名">
        <Icon type="ios-person-outline" slot="prepend"></Icon>
        </Input>
      </FormItem>
      <FormItem prop="passWord">
        <Input type="password" v-model="formInline.passWord" placeholder="密码">
        <Icon type="ios-lock-outline" slot="prepend"></Icon>
        </Input>
      </FormItem>
      <div style="text-align: right; margin-bottom: 20px;">
        <span><a href="#">忘记密码</a></span>
      </div>
      <div style="text-align: center;">
        <Button type="default" @click="handleSignup('formInline')" style="margin-right: 50px;padding: 6px 25px;float: left;">注册</Button>
        <Button type="primary" @click="handleSubmit('formInline')" style="padding: 6px 25px; float: right;">登录</Button>
      </div>
    </Form>
  </div>-->
  <div v-if="isShow">
    <Modal v-model="isShow" width="450"  @on-cancel="goBack">
      <div class="from-title">
        用户登录
      </div>
      <Form ref="formInline" :model="formInline" :rules="ruleInline" style="padding: 5px 20px;">
        <FormItem prop="userName">
          <Input type="text" v-model="formInline.userName" placeholder="用户名">
            <Icon type="ios-person-outline" slot="prepend"></Icon>
          </Input>
        </FormItem>
        <FormItem prop="passWord">
          <Input type="password" v-model="formInline.passWord" placeholder="密码">
            <Icon type="ios-lock-outline" slot="prepend"></Icon>
          </Input>
        </FormItem>
        <div style="text-align: right;">
          <span><a href="#">忘记密码</a></span>
        </div>

      </Form>
      <div style="text-align: center;" slot="footer">
        <Button type="default" @click="goBack" style="margin-right: 50px;padding: 6px 25px;">取消</Button>
        <Button type="primary" @click="handleSubmit('formInline')" style="padding: 6px 25px;">确定</Button>
      </div>
    </Modal>
  </div>

</template>

<script>
  import {api} from "../axios/api";

  export default {
        name: "Login",
      mounted(){
          this.isShow  =true
      },
      data () {
        return {
          isShow:true,
          formInline: {
            userName: '',
            passWord: ''
          },
          ruleInline: {
            userName: [
              { required: true, message: '请输入用户名', trigger: 'blur' }
            ],
            passWord: [
              { required: true, message: '请输入密码', trigger: 'blur' },
              { type: 'string', min: 6, message: '密码最小长度6位', trigger: 'blur' }
            ]
          }
        }
      },
      methods: {
        handleSubmit(name) {
          this.$refs[name].validate((valid) => {
            if (valid) {
              //TODO 认证 权限 cookie 状态 加密
              api.login(this.formInline).then(res=>{
                if (res.data.state === 200) {
                  sessionStorage.setItem('userInfo',JSON.stringify(res.data.userInfo))
                  this.$Message.success('Success!');
                  this.$router.push({path:'/index',name:'Index'})
                }else {
                  this.$Message.error(res.data.msg);
                }
              }).catch(err=>{
                console.log(err);
                this.$Message.error('Fail!');
              })
            } else {
              this.$Message.error('Fail!');
            }
          })
        },
        handleSignup(){
          this.$router.push({path:'/signup',name:'SignUp'})
        },
        goBack(){
          this.isShow = false
          this.$nextTick(()=>{
            this.$router.push({path:'/'})

          })
          console.log(this.isShow);
        }
      }
    }
</script>

<style scoped>
  .from{
    position: absolute;
    top: 20%;
    left: 50%;
    transform: translate(-50%);
    margin: 0 auto;
    padding: 30px 50px;
    width: 450px;
    /*height: 400px;*/
    border: 1px solid #eeeeee;
    box-shadow: 0px 0px 10px 5px #eeeeee;
  }
  .from-title{
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 20px;
  }
</style>
