<template>
    <Layout>
      <iHeader></iHeader>
      <Row class="row-item">
        <Col span="20" offset="2">
          <Input v-model="article.tittle" maxlength="25" placeholder="请输入标题"></Input>
        </Col>
      </Row>
      <Row class="row-item">
        <Col span="20" offset="2">
          <div class="edit-container">
            <quill-editor
              class="blog-editor"
              v-model="article.content"
              ref="myQuillEditor"
              :options="editorOption">
            </quill-editor>
          </div>
        </Col>
      </Row>
      <Row class="row-item">
        <Col span="20" offset="2">
          <div class="cover-title" style="font-size: 16px;padding-bottom: 10px;">
            封面图片（选填）
          </div>
          <!--<div class="upload-list" v-for="item in uploadList">
            <template v-if="item.status === 'finished'">
              <img :src="item.url">
              <div class="upload-list-cover">
                <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
              </div>
            </template>
            <template v-else>
              <Progress v-if="item.showProgress" :percent="item.percentage" hide-info></Progress>
            </template>
          </div>-->
          <div class="upload-list" v-for="item in uploadList">
            <template>
              <img :src="item.url">
              <div class="upload-list-cover">
                <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
              </div>
            </template>
          </div>
          <!--:default-file-list="uploadList"-->
          <Upload
            ref="upload"
            :show-upload-list="false"
            :default-file-list="uploadList"
            :on-success="handleSuccess"
            :format="['jpg','jpeg','png']"
            :max-size="2048"
            :on-format-error="handleFormatError"
            :on-exceeded-size="handleMaxSize"
            :before-upload="handleBeforeUpload"
            multiple
            type="drag"
            :data="uploadParam"
            :action="imgUrl"
            style="display: inline-block;width:58px;">
            <div style="width: 58px;height:58px;line-height: 58px;">
              <Icon type="ios-camera" size="20"></Icon>
            </div>
          </Upload>
        </Col>
      </Row>
      <Row style="text-align: center;margin-bottom: 20px;" class="row-item">
        <Button type="default" style="margin-right: 20px;" @click="saveDoc">保存草稿</Button>
        <Button type="primary">发布文章</Button>
      </Row>
      <iFooter></iFooter>
    </Layout>

</template>

<script>
  import iHeader from '../components/iHeader';
  import iFooter from '../components/iFooter';
  import { quillEditor } from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import quillConfig from './QuillEditorConfig/config.js';
  import {api} from "../axios/api";
  import moment from 'moment';

  export default {
      name: "AddArticle",
      components:{
        quillEditor,
        iHeader,
        iFooter
      },
      data(){
          return{
            imgUrl:'',
            article:{
              tittle:'',
              author:'',
              cover:[],
              content:'',
              moment:'',
              md:'',
              uid:'',
              abstract:''
            },
            uploadParam:{uid:JSON.parse(sessionStorage.getItem('userInfo')).id},
            articleTittle:'',
            editorOption:quillConfig ,
            content:'',
            defaultList: [],
            imgName: '',
            visible: false,
            uploadList: []
          }
      },
      methods:{
        saveDoc(){
          if (this.article.tittle && this.article.content) {
            this.article.moment = moment().format('YYYY-MM-DD hh:mm:ss');
            this.article.abstract=this.article.content.replace(/<(?!img).*?>/g, "").replace(/<(img).*?>/g,'').substr(0,300);
            this.article.cover = this.uploadList.length>0?this.uploadList[0].url:'';
            console.log(this.article);
            api.addArticle(this.article).then(res=>{
              if (res.data.state === 200) {
                this.$Message.success('保存成功')
              }else {
                this.$Message.error(res.data.msg)
              }
            }).catch(err=>{
              console.log(err);
              // this.$Message.error('出错了')
            })
          }else {
            this.$Message.error('请输入内容！')
          }
        },
        handleView (name) {
          this.imgName = name;
          this.visible = true;
        },
        handleRemove (file) {

          const fileList = this.$refs.upload.fileList;
          this.uploadList.splice(fileList.indexOf(file), 1);
          // this.uploadList.splice(this.uploadList.length-1,1)
        },
        handleSuccess (res, file,fileList) {
          file.url = res.data.url;
          this.uploadList =fileList

        },
        handleFormatError (file) {
          this.$Notice.warning({
            title: '文件格式错误',
            desc: '文件'+file.name + '的格式不正确, 请选择jpg或png格式'
          });
        },
        handleMaxSize (file) {
          this.$Notice.warning({
            title: '图片上传大小限制',
            desc: '文件  ' + file.name + '已超出2M'
          });
        },
        handleBeforeUpload (res) {
          const check = this.uploadList.length < 1;
          if (!check) {
            this.$Notice.warning({
              title: '最多上传一张图片'
            });
          }
          return check;
        }
      },
    mounted(){

    },
    created(){
      this.imgUrl=Window.baseURL+'/upload/image';
      if (!sessionStorage.getItem('userInfo')) {
        this.$router.push({path:'/login',name:'Login'});
      }else {
        let userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
        this.article.uid = userInfo.id;
        this.article.author = userInfo.userName;
      }
    }
    }
</script>

<style >
  .ql-container{
    min-height: 400px;
    overflow: hidden;
  }
  .row-item{
    margin-top: 20px;
  }
  .upload-list{
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0,0,0,.2);
    margin-right: 4px;
  }
  .upload-list img{
    width: 100%;
    height: 100%;
  }
  .upload-list-cover{
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,.6);
  }
  .upload-list:hover .upload-list-cover{
    display: block;
  }
  .upload-list-cover i{
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
  }
</style>
