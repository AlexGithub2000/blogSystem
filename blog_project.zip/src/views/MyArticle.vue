<template>
    <Layout>
    <iHeader></iHeader>
    <Content style="font-size: 16px;min-height: 520px;max-width: 1400px;margin: 0 auto;">
      <Row>
        <Col span="20" offset="2">
          <Row>
            <Col span="16" style="padding-right: 20px;margin-top: 20px;">
              <router-link :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}" v-for="(item,index) in articleList" :key="index">
                <Card :bordered="false" class="article-item" >
                  <p slot="title" class="article-title">
                    <router-link class="a-tag"
                                 :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}">
                      {{item.tittle}}</router-link></p>
                  <Row class="article-wrap">
                    <Col span="8" class="article-cover">
                      <img width="100%" height="100%" :src="item.cover" alt="cover image">
                    </Col>
                    <Col span="16" class="article-content" >
                      <p class="article-text" v-html="item.abstract"></p>
                    </Col>
                  </Row>
                </Card>
              </router-link>

            </Col>
            <Col span="8" style="margin-top: 20px;">
              <Card :bordered="false">
                <p slot="title">个人中心</p>
                <p>Content of no border type. Content of no border type. Content of no border type. Content of no border type. </p>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>

    </Content>
      <iFooter></iFooter>
    </Layout>
</template>

<script>
  import iHeader from '../components/iHeader';
  import iFooter from '../components/iFooter';
  import {api} from "../axios/api";

  export default {
    name: "Article",
    components: {
      iHeader,
      iFooter
    },
    data(){
      return{
        uid:'',
        articleList:[]
      }
    },
    created(){
      if (!sessionStorage.getItem('userInfo')) {
        this.$router.push({path:'/login',name:'Login'});
      }else {
        let userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
        this.uid = userInfo.id;
        this.getMyArticle()
        // this.article.author = userInfo.userName;
      }
    },
    methods:{
      getMyArticle(){
        api.getArticleByUid({uid:this.uid}).then(res=>{
          console.log(res);
          if (res.data.state === 200) {
            this.articleList=res.data.articleList
          }
        }).catch(err=>{
          console.log(err);
        })
      }
    }
  }
</script>

<style scoped>
  .article-item{
    margin-bottom: 20px;
    height: 210px;
  }
  .article-wrap{
    display: flex;
    overflow: hidden;
    height: 130px;
  }
  .article-title{
    font-size: 20px;
  }
  .article-content{
    padding-left: 16px;
    font-size: 16px;
  }
  .article-text{
    color: #101a27;
    display:-webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 5;
    overflow:hidden;
  }
</style>
<style>
  .a-tag{
    color: #17233d;
  }
  .a-tag:hover{
    color: rgba(23, 35, 61, 0.6);
  }
</style>
