<template>
  <div class="sign-up" v-if="isModalShow">
    <Modal v-model="isModalShow"  @on-cancel="cancel">
      <div class="sign-up-title">
        用户注册
      </div>
      <Form ref="formCustom" :model="formCustom" style="padding: 5px 20px;" :rules="ruleCustom" :label-width="80">
        <FormItem label="用户名" prop="userName">
          <Input type="text" v-model="formCustom.userName"></Input>
        </FormItem>
        <FormItem label="密码" prop="passWord">
          <Input type="password" v-model="formCustom.passWord"></Input>
        </FormItem>
        <FormItem label="确认密码" prop="passWordCheck">
          <Input type="password" v-model="formCustom.passWordCheck"></Input>
        </FormItem>
        <FormItem label="邮箱" prop="email">
          <Input type="email" v-model="formCustom.email" email></Input>
        </FormItem>
        <FormItem label="手机号" prop="phone">
          <Input type="text" v-model="formCustom.phone" number></Input>
        </FormItem>

        <div style="text-align: right;">
          <router-link to="/login">已有账号，去登陆>></router-link>
        </div>
      </Form>
      <div slot="footer" style="text-align: center; margin-bottom: 15px;">
        <Button type="primary" @click="handleSubmit('formCustom')">提交</Button>
        <Button @click="handleReset('formCustom')" style="margin-left: 8px">重置</Button>
      </div>
    </Modal>

  </div>

</template>

<script>
  import {api} from "../axios/api";

  export default {
      name: "SignUp",
    mounted(){
        this.isModalShow = true
    },
      data () {
        const validatePass = (rule, value, callback) => {
          if (value === '') {
            callback(new Error('请输入密码'));
          } else {
            if (this.formCustom.passWordCheck !== '') {
              // 对第二个密码框单独验证
              this.$refs.formCustom.validateField('passWordCheck');
            }
            callback();
          }
        };
        const validatePassCheck = (rule, value, callback) => {
          if (value === '') {
            callback(new Error('请再次输入密码'));
          } else if (value !== this.formCustom.passWord) {
            callback(new Error('两次密码输入不一致'));
          } else {
            callback();
          }
        };
        const validatePhone = (rule, value, callback) => {
          if (value) {
            if (!/^1[34578]\d{9}$/.test(value)) {
              callback(new Error('手机号格式不正确'));
            }else {
              callback();
            }
          } else {
            callback();
          }
        };

        return {
          isModalShow:true,
          formCustom: {
            userName:'111111',
            passWord: '123456',
            passWordCheck: '123456',
            phone: '18675586616',
            email:'44@qq.com',
          },
          ruleCustom: {
            userName:[
              {require:true,message:'请输入用户名',trigger:'blur'},
              { type: 'string', max: 20, message: '不能超过20个字符', trigger: 'blur' },
            ],
            passWord: [
              { validator: validatePass, trigger: 'blur', },
              { type: 'string', min: 6, message: '最少6个字符', trigger: 'blur' },
            ],
            passWordCheck: [
              { validator: validatePassCheck, trigger: 'blur' }
            ],
            email: [
              // { validator: validatePhone, trigger: 'blur' }
              { require: true,message:'请输入邮箱', trigger: 'blur' },
              { type: 'email',message:'输入邮箱格式不正确', trigger: 'blur' }
            ],
            phone: [
              { validator: validatePhone, trigger: 'blur' }
              // { require: false,message:'请输入手机号', trigger: 'blur' },
              // { type: 'number',message:'输入手机号不正确',pattern :/^1[34578]\d{9}$/, trigger: 'blur' }
            ]
          }
        }
      },
      methods: {
        cancel(){
          this.isModalShow=false
          this.$nextTick(()=>{
            this.$router.push({path:'/'})
          })
        },
        handleSubmit (name) {
          this.$refs[name].validate((valid) => {
            if (valid) {
              // this.$Message.success('Success!');
              console.log(this.formCustom);
              api.signUp(this.formCustom).then(res=>{
                console.log(res)
                if (res.data.state === 200) {
                  this.$Message.success('注册成功！');
                  this.$refs[name].resetFields();
                }
              }).catch(err=>{
                console.log(err)
              })
            } else {
              this.$Message.error('输入有误！');
            }
          })
        },
        handleReset (name) {
          this.$refs[name].resetFields();
        }
      }
    }
</script>

<style scoped>
.sign-up{
  position: absolute;
  top: 20%;
  left: 50%;
  transform: translate(-50%);
  margin: 0 auto;
  padding: 30px;
  width: 450px;
  /*height: 400px;*/
  border: 1px solid #eeeeee;
  box-shadow: 5px 5px 5px #eeeeee;
}
  .sign-up-title{
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 20px;
  }
</style>
