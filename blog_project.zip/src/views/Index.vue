<template>
  <div class="layout">
    <Layout>
      <!--<Header class="blog-header">Header</Header>-->
      <iHeader></iHeader>

      <Content class="blog-content" >
        <div class="blog-top">
          <div class="blog-banner">
            <Carousel class="blog-carousel" autoplay v-model="value2" loop style="background: #000;">
            <CarouselItem v-for="(item,index) in starList" :key="index">
              <router-link :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}" >
              <div class="demo-carousel" style="position: relative;">
                <span class="car-item-tittle">{{item.tittle}}{{item.id}}</span>
                <img :src="item.cover" alt="" width="100%" height="450px">
              </div>
              </router-link>
            </CarouselItem>
          </Carousel>
            <div class="top-single">
              <div class="single-item" style="position: relative;">
                <span class="single-item-tittle">精选</span>
                <img src="/static/images/1.jpg" alt="" width="100%" height="100%">
              </div>
              <div class="single-item" style="position: relative;">
                <span class="single-item-tittle">分类</span>
                <img src="/static/images/2.jpg" alt="" width="100%" height="100%">
              </div>
            </div>
          </div>
        </div>
        <!--<Row class="recommend-content">
          <div class="blog-card" style="text-align:center">
            <img width="100%" height="100%" src="/static/images/7.jpg">
            &lt;!&ndash;<h3>A high quality UI Toolkit based on Vue.js</h3>&ndash;&gt;
          </div>
          <div class="blog-card" style="text-align:center">
            <img width="100%" height="100%" src="/static/images/7.jpg">
            &lt;!&ndash;<h3>A high quality UI Toolkit based on Vue.js</h3>&ndash;&gt;
          </div>
          <div class="blog-card" style="text-align:center">
            <img width="100%" height="100%" src="/static/images/7.jpg">
            &lt;!&ndash;<h3>A high quality UI Toolkit based on Vue.js</h3>&ndash;&gt;
          </div>
        </Row>-->
        <div class="blog-bottom">
          <div class="blog-article">
            <router-link :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}" v-for="(item,index) in articleList" :key="index">
              <Card :bordered="false" class="article-item" >
                <p slot="title" class="article-title">
                  <router-link class="a-tag"
                               :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}">
                    {{item.tittle}}</router-link></p>
                <Row class="article-wrap">
                  <Col span="8" class="article-cover">
                    <img width="100%" height="100%" :src="item.cover" alt="cover image">
                  </Col>
                  <Col span="16" class="article-content" >
                    <p class="article-text" v-html="item.abstract"></p>
                  </Col>
                </Row>
                <Row>
                  <Col class="article-icon">
                    <span><Icon type="ios-person" /> {{item.author}}</span>
                    <span><Icon type="ios-eye" /> {{item.pv}}</span>
                    <span><Icon type="ios-chatboxes" /> {{item.comments}}</span>
                    <span><Icon type="ios-star" /> {{item.star}}</span>
                  </Col>
                </Row>
              </Card>
            </router-link>

          </div>
          <div class="blog-sider">
            <Card :bordered="false" class="sider-item">
              <p slot="title">热门推荐</p>
              <router-link :to="{path:`/article/detail/${item.id}`,name:'ArticleDetail',params:{id:item.id}}" v-for="item in secondStar" :key="item.index">
                <div class="recommend-article"  style="display:flex;">
                  <div>
                    <Avatar icon="ios-person" shape="square" v-if="item.cover" :src="item.cover" />
                    <Avatar icon="ios-person" shape="square" v-else/>
                  </div>
                  <div class="recommend-article-tittle">{{item.tittle}}</div>
                </div>
              </router-link>

            </Card>
            <Card :bordered="false" class="sider-item">
              <p slot="title">联系我们</p>
              <p>电话：1860000000</p>
              <p>地址：深圳市南山区科技北x号</p>
            </Card>
          </div>
        </div>
      </Content>
      <iFooter></iFooter>
    </Layout>
    <router-view></router-view>
  </div>
</template>

<script>
  import iHeader from '../components/iHeader'
  import iFooter from '../components/iFooter'
  import {api} from "../axios/api";

  export default {
        name: "Index",
      components:{
          iHeader,
        iFooter
      },
      data () {
        return {
          value2: 0,
          articleList:[],
          uid:'',
          starList:[],
          secondStar:[]
        }
      },
      mounted(){
        this.getArticleList();
        this.getStarArticle();
      },
      methods:{
          getArticleList(){
            let userInfo = sessionStorage.getItem('userInfo');
            if (userInfo) {
              this.uid = userInfo.id
            }

            api.getArticle({uid:this.uid}).then(res=>{
              if (res.data.state === 200){
                this.articleList= res.data.articleList;
              }else {
                this.$Message.error(res.data.msg)
              }
            }).catch(err=>{
              console.log(err);
            })
          },
        getStarArticle(){
          api.getMostStar().then(res=>{
            console.log(res);
            if (res.data.state === 200) {
              console.log(res.data.starList);
              this.starList = res.data.starList
              this.secondStar = res.data.secondStar
            }else {
              this.$Message.error(`出错了，${res.data.msg}`)
            }
          })
        }
      }
    }
</script>

<style scoped>
  .layout{
    /*height: 100%;*/
    overflow-y: auto;
  }

.blog-content{
  /*height: 100%;*/
  margin: 0 auto;
  /*padding: 20px 150px;*/

}
  .blog-footer{
    color: #efefef;
    background: #515a6e;
    text-align: center;
  }
  .blog-top{
    margin-top: 20px;
  }
  .blog-banner{
    height: 450px;
    display: flex;
    overflow: hidden;
  }
  .blog-carousel{
    width:740px;
    height: 450px;
  }

  .car-item-tittle {
    position: absolute;
    bottom: 0px;
    width: 100%;
    height: 80px;
    padding-top: 15px;
    background: rgba(0, 0, 0, 0.36);
    font-size: 30px;
    font-weight: 700;
    color: #e7e7e7;
  }
  .top-single{
    /*flex: 1;*/
    margin-left: 20px;
    width: 360px;
    /*height: 195px;*/
    height: 100%;

  }
  .single-item{
    height: 215px;
    margin-bottom: 20px;
    width: 100%;
    background: #6b6b6b;
  }
  .single-item:last-child{
    margin-bottom: 0;
  }
  .single-item span{
    position: absolute;
    bottom: 0;
  }
  .single-item-tittle {
    position: absolute;
    bottom: 0px;
    width: 100%;
    height: 40px;
    /*padding-top: 15px;*/
    background: rgba(0, 0, 0, 0.36);
    font-size: 20px;
    /*font-weight: 700;*/
    color: #e7e7e7;
  }
  .recommend-content{
    display: flex;
    margin-top: 20px;
  }
  .blog-card{
    width: 360px;
    height: 200px;
    float: left;
    margin-right: 20px;
  }
  .blog-card:last-child{
    margin-right: 0;
  }
  .blog-bottom{
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .blog-article{
    float: left;
    width: 740px;
    height: auto;
    margin-right: 20px;
    margin-bottom: 20px;
  }
  .article-item{
    margin-bottom: 20px;
    min-height: 210px;
  }
  .blog-sider{
    width: 360px;
    float: right;
  }
  .sider-item{
    margin-bottom: 20px;
  }
  .blog-avatar{
    width: 40px;
    height: 40px;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
  }
  .article-wrap{
    display: flex;
    overflow: hidden;
    height: 130px;
  }
  .article-title{
    font-size: 20px;
  }
  .article-content{
    padding-left: 16px;
    font-size: 16px;
  }
  .article-text{
    color: #101a27;
    display:-webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 5;
  overflow:hidden;
  }
  .article-icon{
    text-align: right;
    color:#8e8f92;
    font-size: 14px;
  }
  .article-icon span:not(:last-child){
    padding-right: 10px;
  }
  .recommend-article{
    padding: 5px;
  }
  .recommend-article-tittle{
    font-weight: 700;
    padding-left: 15px;
    color: #282a39;
  }
</style>
<style>
  .ivu-layout{
    /*height: 100%;*/
  }
  .ivu-layout-footer{
    padding: 20px 50px;
  }
  .a-tag{
    color: #17233d;
  }
  .a-tag:hover{
    color: rgba(23, 35, 61, 0.6);
  }
</style>
