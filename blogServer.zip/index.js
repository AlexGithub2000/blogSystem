const Koa = require('koa');
var cors = require('koa2-cors');
const app = new Koa();
const path = require('path');
const serve = require("koa-static");
const config = require('./config/defalult');
const debug = require('debug')('koa-weapp-demo');
const session = require('koa-session-minimal');
const MysqlStore = require('koa-mysql-session');
const response = require('./middlewares/response');
const bodyParser = require('koa-bodyparser');
// const https = require('https');

// session存储配置
const sessionMysqlConfig = {
    user: config.database.USERNAME,
    password: config.database.PASSWORD,
    database: config.database.DATABASE,
    host: config.database.HOST,
};

// 配置session中间件
app.use(
  session({
    key: 'USER_SID',
    store: new MysqlStore(sessionMysqlConfig)
  })
);


app.use(cors());
// 引入路由分发
// 使用响应处理中间件
app.use(response);

// 解析请求体
app.use(bodyParser());
const router = require('./routes');
app.use(router.routes());

app.keys = ['im a newer secret', 'i like turtle'];
app.use(serve(__dirname+ "/webapp/",{ extensions: ['html']}));
app.use(serve(__dirname+ "/public/"));
// app.use(async (ctx,next) =>{
//   const start = Date.now();
//   ctx.cookies.set('name', 'tobi', { signed: true });
//   await next();
//   const ms = Date.now() - start;
//   ctx.set('X-Response-Time', `${ms}ms`);
//   const rt = ctx.response.get('X-Response-Time');
//   console.log(ctx.ip);
//   // ctx.body = `${ctx.method} ${ctx.url} - ${rt}`
// })

app.on('error', (err, ctx) => {
  log.error('server error', err, ctx)
});
// https.createServer(app.callback()).listen(3001);
app.listen(config.port);
console.log('server started','http://localhost:'+config.port);

