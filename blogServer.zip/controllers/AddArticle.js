const sql = require('../tools/mysql');
const config = require('../config/defalult');
// console.log(config.baseUrl+'/defaultCover/cover_'+randomNumBoth(1, 4)+'.jpg');
module.exports = async (ctx)=>{
  let {author,content,tittle,moment,cover,md,uid,abstract} = ctx.request.body;
  if (!cover) {
      cover = config.baseUrl+'/defaultCover/cover_'+randomNumBoth(1, 4)+'.jpg'
  }
  try {
    if (tittle && content && uid) {
      const res = await sql.insertPost([author,tittle,content,md,uid,moment,cover,abstract]);
      console.log(res);
      ctx.state.data={
        state:200,
        msg:'保存成功'
      }
    }else {
      ctx.state.data = {
        state:-1,
        msg:'参数有误'

      }
    }
  }catch (e) {
    ctx.state.data = {
      state:-1,
      msg:'保存失败：'

    };
    console.log(e);
    console.log(e.sqlMessage);
  }
}
function randomNumBoth(Min,Max){
  let Range = Max - Min;
  let Rand = Math.random();
  let num = Min + Math.round(Rand * Range); //四舍五入
  return num;
}
