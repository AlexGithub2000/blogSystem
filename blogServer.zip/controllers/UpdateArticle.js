const sql = require('../tools/mysql');

module.exports = async (ctx)=>{

  try {
    const {tittle,content,abstract,cover,moment,id} = ctx.request.body;
    if (id) {
      const articleList = await sql.updatePost([tittle,content,abstract,cover,moment,id]);
      console.log(articleList);
      ctx.state.data={
        state:200,
        msg:'查询成功',

      }
    }else {
      // const articleList = await sql.findAllPost()
      ctx.state.data={
        state:-1,
        msg:'查询失败',
        // articleList
      }
    }
  }catch (e) {
    console.log(e)
    console.log(e.sqlMessage)
    ctx.state.data={
      state:500,
      msg:'服务错误',
    }
  }
};
