/**
 * Welcome To Code World !!!
 * Author : Administrator
 * Date   : 2019/2/11 21:59
 * Last Modified : name
 * Good Luck! Happy Codding Young Man !!!
 */
const sql = require('../tools/mysql');

module.exports = async (ctx)=>{

  try {
    const {id} = ctx.request.body;
    if (id) {
      const res = await sql.deletePost(id);
      console.log(res);
      ctx.state.data={
        state:200,
        msg:'删除成功',

      }
    }else {
      // const articleList = await sql.findAllPost()
      ctx.state.data={
        state:-1,
        msg:'删除失败',
        // articleList
      }
    }
  }catch (e) {
    console.log(e)
    console.log(e.sqlMessage)
    ctx.state.data={
      state:500,
      msg:'服务错误',
    }
  }
};
