
const sql = require('../tools/mysql');

module.exports = async (ctx)=>{
  // const {articleId} = ctx.request.body;
  try {

      const starList = await sql.getMostStar();
      const secondStar = await sql.getSecondStar();
      ctx.state.data={
        state:200,
        msg:'查询成功',
        starList,
        secondStar
      };

      // const articleList = await sql.findAllPost()
     /* ctx.state.data={
        state:-1,
        msg:'查询失败',
        // articleList
      }*/

  }catch (e) {
    console.log(e)
    console.log(e.sqlMessage)
    ctx.state.data={
      state:500,
      msg:'服务错误',
    }
  }
};
