const sql = require('../tools/mysql');

module.exports = async (ctx)=>{
  const {articleId} = ctx.request.body;
  try {
    if (articleId) {
      const articleList = await sql.findDataById(articleId);
      ctx.state.data={
        state:200,
        msg:'查询成功',
        article:articleList[0]
      };

      await sql.updatePostPv([articleList[0].pv+1,articleId])
    }else {
      // const articleList = await sql.findAllPost()
      ctx.state.data={
        state:-1,
        msg:'查询失败',
        // articleList
      }
    }
  }catch (e) {
    console.log(e)
    console.log(e.sqlMessage)
    ctx.state.data={
      state:500,
      msg:'服务错误',
    }
  }
};
