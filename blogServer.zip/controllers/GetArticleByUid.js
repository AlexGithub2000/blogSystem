const sql = require('../tools/mysql');

module.exports = async (ctx)=>{
  const {uid} = ctx.request.body;
  try {
    if (uid) {
      const articleList = await sql.getArticleListByUid(uid);
      ctx.state.data={
        state:200,
        msg:'查询成功',
        articleList
      }
    }else {
      // const articleList = await sql.findAllPost()
      ctx.state.data={
        state:-1,
        msg:'查询失败',
        // articleList
      }
    }
  }catch (e) {
    console.log(e)
    console.log(e.sqlMessage)
    ctx.state.data={
      state:500,
      msg:'服务错误',
    }
  }
};
