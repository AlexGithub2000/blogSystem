const moment = require('moment');
const sql = require('../tools/mysql');
// console.log(sql.insertUserData);

module.exports =async (ctx)=>{
    const {userName,passWord,phone,email} = ctx.request.body;
    let date = moment().format('YYYY-MM-DD hh:mm:ss');
    console.log(userName,passWord,phone,email,date);
    try {
      if (userName && passWord) {
        await sql.insertUserData([userName,passWord,phone,email,date]);
        ctx.state.data={
          state:200,
          msg:'注册成功'
        }
      }else {
        ctx.state.data={
          state:-1,
          msg:'参数错误'
        }
      }
    }catch (e) {
      ctx.state.data = {
        state:-1,
        msg:'注册失败：'+e.sqlMessage
      }
    }
};
