const formidable = require('koa-formidable');
const config = require('../config/defalult');
const fs = require('fs');
const path = require('path'); // 图片路径

module.exports =async (ctx, next) =>{
  try {
    const {url,name} = await writeImg(ctx)
    if (url) {
      ctx.state.data={
        state:200,
        url,
        name,
        msg:'保存成功'
      }
    }else {
      ctx.state.data={
        state:-1,
        msg:'参数错误，保存失败'
      }
    }
  }catch (e) {
    ctx.state.data={
      state:500,
      data: null,
      msg:'保存失败'
    }
    console.log(e);
  }finally {
    console.log('finally')
  }

  // return {flag: '1',msg:'',data: url} // 路径返回给前端
};


function writeImg(ctx) {
  return new Promise( (resolve, reject) => {
    let form = formidable.parse(ctx.request);
    form(async (opt, obj) => {
      // console.log(opt, obj);
      let uid =obj.fields.uid;
      console.log(uid);
      if (uid == undefined) {
        reject({name:null,url:null})
      }
      let  file = obj.files.file;
      let  filename = file.name;
      let savePath = `${config.path.publicPath}/img/${uid}`;
      console.log(savePath);
      await mkdirs(savePath);
      const imgPath = path.join(savePath, filename);
      const reader = fs.createReadStream(file.path);
      const writer = fs.createWriteStream(imgPath);
      // const savePath = await writeImg(writer,filename);
      // console.log(savePath);
      let stream = reader.pipe(writer);
      stream.on('finish', function () {
        resolve({url:`${config.baseUrl}/img/${uid}/${filename}`,name:filename});
      });
    });

  })
}

// 新建文件，可以去百度fs模块
let mkdirs = (dirname)=> {
  return new Promise(resolve => {
    fs.exists(dirname, function(exists) {
      if (exists) {
        resolve();
      } else {
        fs.mkdir(dirname, ()=>{
          resolve();
        });
      }
    });
  })

};
