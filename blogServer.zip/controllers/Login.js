const sql = require('../tools/mysql')
module.exports =async (ctx)=>{
  const {userName,passWord} = ctx.request.body;
  try {
    if (userName && passWord) {
      const userData = await sql.findUserData([userName])
      if (userName===userData[0]['username']){
        if (passWord === userData[0]['password']) {
          ctx.state.data={
            state:200,
            userInfo:{id:userData[0]['id'],userName:userData[0]['username']},
            msg:'登录成功'
          }
        }else {
          ctx.state.data={
            state:400,
            msg:'登录信息有误'
          }
        }
      } else {
        ctx.state.data={
          state:400,
          msg:'登录信息有误'
        }
      }

    }else {
      ctx.state.data = {
        code:-1,
        data:{
          state:400,
          msg:'登录失败：'
        }

      }
    }
  }catch (e) {
    ctx.state.data = {
      code:-1,
      data:{
        state:400,
        msg:'登录失败：'
      }

    }
    console.log(e.sqlMessage);
  }
}
