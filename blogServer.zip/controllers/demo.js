/**
 * Welcome To Code World !!!
 * Author : Administrator
 * Date   : 2019/1/28 21:30
 * Last Modified : name
 * Good Luck! Happy Codding Young Man !!!
 */
module.exports = async (ctx)=>{
    ctx.state.data={
        msg:'小程序后台，小程序后台'
    }
}