const router = require('koa-router')({
  prefix: '/blog'
})
const controllers = require('../controllers')


// router.get('/', controllers.login)
router.get('/demo', controllers.demo);
router.post('/login', controllers.Login);
router.post('/signup', controllers.SignUp);
router.post('/add/article', controllers.AddArticle);
router.post('/upload/image', controllers.UploadImage);
router.post('/get/article', controllers.GetArticle);
router.post('/get/article/detail', controllers.GetArticleDetail);
router.post('/get/article/mine', controllers.GetArticleByUid);
router.post('/update/article', controllers.UpdateArticle);
router.post('/delete/article', controllers.DeleteArticle);
router.post('/get/star/article', controllers.GetStarArticle);

module.exports = router
