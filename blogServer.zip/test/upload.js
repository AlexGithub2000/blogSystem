// app.js
const Router = require('koa-router');
const router = new Router();
const serve = require("koa-static");

const formidable = require('koa-formidable'); // 图片处理
const fs = require('fs'); // 图片路径
const path = require('path'); // 图片路径

app.use(serve(__dirname))  // 设置静态文件

// 新建文件，可以去百度fs模块
let mkdirs = (dirname, callback)=> {
  fs.exists(dirname, function(exists) {
    if (exists) {
      callback();
    } else {
      mkdirs(path.dirname(dirname), function() {
        fs.mkdir(dirname, callback);
      });
    }
  });
};

router.post('/upload/image', async function (ctx, next) {
  let form = formidable.parse(request);
  function formImage() {
    return new Promise((resolve, reject) => {
      form((opt, {fields, files})=> {
        let url = fields.url;
        let articleId = fields.articleId;
        let filename = files.file.name;
        console.log(files.file.path);
        let uploadDir = 'public/upload/';
        let avatarName = Date.now() + '_' + filename;
        mkdirs('public/upload', function() {
          fs.renameSync(files.file.path, uploadDir + avatarName); //重命名
          resolve(config[env].host + '/' + uploadDir + avatarName)
          // http://localhost:6001/public/upload/1513523744257_WX20171205-150757.png
        })
      })
    })
  }
  let url = await formImage();
  return {flag: '1',msg:'',data: url} // 路径返回给前端
});

app
  .use(router.routes())
  .use(router.allowedMethods());
