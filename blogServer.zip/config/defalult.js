// 数据库配置
const path = require('path');
console.log(process.env.NODE_ENV);
const config ={
  port:3000,
  database:{
    DATABASE:'blog',
    USERNAME:'root',
    PASSWORD:'Mysql@75586616',
    PORT:3306,
    HOST:'69.85.85.110'
  },
  baseUrl:process.env.NODE_ENV === 'development' ? 'http://localhost:3000' :'http://blog.wangtianping.com',

  path:{
    basePath:path.resolve(),
    publicPath:path.resolve('public'),
    webappPath:path.resolve('webapp'),
  }
};

module.exports=config;
