var mysql      = require('mysql');
var config = require('../config/defalult')

var pool  = mysql.createPool({
    host     : config.database.HOST,
    user     : config.database.USERNAME,
    password : config.database.PASSWORD,
    database : config.database.DATABASE
});

const query = function( sql, values ) {

    return new Promise(( resolve, reject ) => {
        pool.getConnection(function(err, connection) {
            if (err) {
                reject( err )
            } else {
                connection.query(sql, values, ( err, rows) => {

                    if ( err ) {
                        reject( err )
                    } else {
                        resolve( rows )
                    }
                    connection.release()
                })
            }
        })
    })

};


let users =`CREATE TABLE if not exists userinfo (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(100) NOT NULL,
  password varchar(100) NOT NULL,
  phone varchar(255) DEFAULT NULL,
  email varchar(255) DEFAULT NULL,
  moment datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`;


let posts =
  `create table if not exists posts(
     id INT NOT NULL AUTO_INCREMENT,
     name VARCHAR(100) NOT NULL,
     title TEXT(0) NOT NULL,
     content TEXT(0) NOT NULL,
     md TEXT(0) NOT NULL,
     uid VARCHAR(40) NOT NULL,
     moment VARCHAR(100) NOT NULL,
     comments VARCHAR(200) NOT NULL DEFAULT '0',
     pv VARCHAR(40) NOT NULL DEFAULT '0',
     avatar VARCHAR(100) NOT NULL,
     PRIMARY KEY ( id )
    );`

let comment =
  `create table if not exists comment(
     id INT NOT NULL AUTO_INCREMENT,
     name VARCHAR(100) NOT NULL,
     content TEXT(0) NOT NULL,
     moment VARCHAR(40) NOT NULL,
     postid VARCHAR(40) NOT NULL,
     avatar VARCHAR(100) NOT NULL,
     PRIMARY KEY ( id )
    );`

let createTable = function( sql ) {
    return query( sql, [] )
}

// 建表
createTable(users);
createTable(posts);
createTable(comment);
// 注册用户
let insertUserData = function( value ) {
  // userName,passWord,phone,email,date
    let _sql = "insert into userinfo set userName=?,passWord=?,phone=?,email=?,moment=?;"
    return query( _sql, value )
}
// 删除用户
let deleteUserData = function( name ) {
    let _sql = `delete from users where name="${name}";`
    return query( _sql )
}
// 查找用户
let findUserData = function( name ) {
    let _sql = `select * from userinfo where username="${name}";`
    return query( _sql )
}
// 发表文章
let insertPost = function( value ) {
    let _sql = "insert into posts set author=?,tittle=?,content=?,md=?,uid=?,moment=?,cover=?,abstract=?;"
    return query( _sql, value )
}
// 更新文章评论数
let updatePostComment = function( value ) {
    let _sql = "update posts set comments=? where id=?"
    return query( _sql, value )
}

// 更新浏览数
let updatePostPv = function( value ) {
    let _sql = "update posts set pv=? where id=?"
    return query( _sql, value )
}

// 发表评论
let insertComment = function( value ) {
    let _sql = "insert into comment set name=?,content=?,moment=?,postid=?,avatar=?;"
    return query( _sql, value )
}
// 通过名字查找用户
let findDataByName = function ( name ) {
    let _sql = `select * from users where name="${name}";`
    return query( _sql)
}
// 通过文章的名字查找用户
let findDataByUser = function ( name ) {
    let _sql = `select * from posts where name="${name}";`
    return query( _sql)
}
// 通过文章id查找
let findDataById = function ( id ) {
    let _sql = `select id,tittle,author,cover,content,moment,uid,abstract,pv from posts where id=?;`;
    return query( _sql,[id]);
}
//获取用户文章列表
let getArticleListByUid = function(uid){
  let _sql = `select id,author,tittle,content,abstract,uid,cover,moment,pv,comments FROM posts where uid=? and deleted = '0' order by moment desc;`
  return query( _sql,[uid])
}
// 通过评论id查找
let findCommentById = function ( id ) {
    let _sql = `select * FROM comment where postid="${id}";`
    return query( _sql)
}

// 查询文章列表
let findAllPost = function () {
    let _sql = ` select id,author,tittle,abstract,moment,uid,pv,cover,comments,star FROM posts where deleted = '0' order by moment desc;`
    return query( _sql)
}
// 查询分页文章
let findPostByPage = function (page) {
    let _sql = ` select * FROM posts limit ${(page-1)*10},10;`
    return query( _sql)
}
// 查询个人分页文章
let findPostByUserPage = function (name,page) {
    let _sql = ` select * FROM posts where name="${name}" order by id desc limit ${(page-1)*10},10`
    return query( _sql)
}
// 更新修改文章
let updatePost = function(values){
    let _sql = `update posts set  tittle=?,content=?,abstract=?,cover=?,moment=? where id=?`;
    return query(_sql,values)
}
// 删除文章
let deletePost = function(id){
    let _sql = `update posts set deleted='1' where id = ?`;
    return query(_sql,[id])
}
// 删除评论
let deleteComment = function(id){
    let _sql = `delete from comment where id=${id}`
    return query(_sql)
}
// 删除所有评论
let deleteAllPostComment = function(id){
    let _sql = `delete from comment where postid=${id}`
    return query(_sql)
}
// 查找评论数
let findCommentLength = function(id){
    let _sql = `select content from comment where postid in (select id from posts where id=${id})`
    return query(_sql)
}

// 滚动无限加载数据
let findPageById = function(page){
    let _sql = `select * from posts limit ${(page-1)*5},5;`
    return query(_sql)
}
// 评论分页
let findCommentByPage = function(page,postId){
    let _sql = `select * from comment where postid=${postId} order by id desc limit ${(page-1)*10},10;`
    return query(_sql)
}
// 获取最多星
let getMostStar = function(){
  let _sql = `select id,author,tittle,cover from posts where deleted='0' order by star desc limit 4;`;
  return query(_sql)
};
// 获取次多星
let getSecondStar = function(){
  let _sql = `select id,author,tittle,cover,(select avatar from userinfo where id =p.uid)avatar from posts p where deleted='0' order by star desc limit 5,10`;
  return query(_sql)
};

module.exports = {
    query,
    getMostStar,
    getSecondStar,
    createTable,
    insertUserData,
    deleteUserData,
    findUserData,
    findDataByName,
    insertPost,
    findAllPost,
    findPostByPage,
    findPostByUserPage,
    findDataByUser,
    findDataById,
    insertComment,
    findCommentById,
    updatePost,
    deletePost,
    deleteComment,
    findCommentLength,
    updatePostComment,
    deleteAllPostComment,
    updatePostPv,
    findPageById,
    findCommentByPage,
    getArticleListByUid
}
